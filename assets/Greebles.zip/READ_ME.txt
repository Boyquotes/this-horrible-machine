Thank you for purchasing this asset pack!



This pack contains 16 low poly static meshes that are fully UV mapped and include templates for the creation of custom textures. 
These meshes can be used in any 3D software that accept both the FBX format.

If you have further questions or concerns, please contact me at siristhedragon@gmail.com
